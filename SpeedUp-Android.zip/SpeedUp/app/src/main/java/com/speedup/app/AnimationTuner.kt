package com.speedup.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * يقرأ/يغيّر سرعة الأنيميشن (نفس خيارات المطور الثلاثة).
 * التغيير يحتاج صلاحية WRITE_SECURE_SETTINGS التي تُمنح مرة واحدة عبر adb.
 */
object AnimationTuner {

    fun canWrite(context: Context): Boolean =
        context.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    fun get(context: Context): Float = try {
        Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
    } catch (e: Exception) {
        1f
    }

    fun set(context: Context, scale: Float): Boolean = try {
        val cr = context.contentResolver
        val a = Settings.Global.putFloat(cr, Settings.Global.WINDOW_ANIMATION_SCALE, scale)
        val b = Settings.Global.putFloat(cr, Settings.Global.TRANSITION_ANIMATION_SCALE, scale)
        val c = Settings.Global.putFloat(cr, Settings.Global.ANIMATOR_DURATION_SCALE, scale)
        a && b && c
    } catch (e: SecurityException) {
        false
    }
}
