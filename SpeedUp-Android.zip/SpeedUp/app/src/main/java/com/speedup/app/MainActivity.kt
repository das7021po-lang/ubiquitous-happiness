package com.speedup.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.speedup.app.ui.AppsScreen
import com.speedup.app.ui.FilesScreen
import com.speedup.app.ui.HomeScreen
import com.speedup.app.ui.SpeedUpTheme
import com.speedup.app.ui.ToolsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SpeedUpTheme {
                SpeedUpApp()
            }
        }
    }
}

private enum class AppTab(val title: String, val icon: ImageVector) {
    Home("الرئيسية", Icons.Filled.Speed),
    Apps("التطبيقات", Icons.Filled.Apps),
    Files("الملفات", Icons.Filled.Storage),
    Tools("أدوات", Icons.Filled.Build)
}

@Composable
private fun SpeedUpApp() {
    var tabIndex by rememberSaveable { mutableStateOf(0) }
    val tabs = AppTab.values()

    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tabIndex == i,
                        onClick = { tabIndex = i },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title) }
                    )
                }
            }
        }
    ) { padding ->
        val mod = Modifier.padding(padding)
        when (tabs[tabIndex]) {
            AppTab.Home -> HomeScreen(mod) { tabIndex = it }
            AppTab.Apps -> AppsScreen(mod)
            AppTab.Files -> FilesScreen(mod)
            AppTab.Tools -> ToolsScreen(mod)
        }
    }
}
