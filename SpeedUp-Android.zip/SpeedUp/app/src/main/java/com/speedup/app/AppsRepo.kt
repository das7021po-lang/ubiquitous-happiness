package com.speedup.app

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.os.Process
import android.os.storage.StorageManager

data class AppRow(
    val pkg: String,
    val label: String,
    /** تطبيق نظام لم يُحدَّث (لا يمكن إلغاء تثبيته) */
    val isSystemApp: Boolean,
    /** -1 = غير معروف */
    val cacheBytes: Long,
    /** -1 = غير معروف */
    val totalBytes: Long,
    /** 0 = غير معروف / لم يُستخدم منذ مدة طويلة */
    val lastUsed: Long
)

object AppsRepo {

    fun hasUsageAccess(context: Context): Boolean {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** عمل ثقيل نسبيًا: شغّله خارج الخيط الرئيسي. */
    @Suppress("DEPRECATION")
    fun load(context: Context): List<AppRow> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = pm.queryIntentActivities(launcher, 0)
            .mapNotNull { it.activityInfo?.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != context.packageName }

        val usage = hasUsageAccess(context)
        val lastUsedMap: Map<String, Long> = if (usage) lastUsed(context) else emptyMap()
        val ssm = context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val me = Process.myUserHandle()

        return infos.map { ai ->
            var cache = -1L
            var total = -1L
            if (usage) {
                try {
                    val st = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, ai.packageName, me)
                    cache = st.cacheBytes
                    total = st.appBytes + st.dataBytes
                } catch (e: Exception) {
                    // تعذّر قياس هذا التطبيق، نتركه "غير معروف"
                }
            }
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            AppRow(
                pkg = ai.packageName,
                label = pm.getApplicationLabel(ai).toString(),
                isSystemApp = isSystem,
                cacheBytes = cache,
                totalBytes = total,
                lastUsed = lastUsedMap[ai.packageName] ?: 0L
            )
        }
    }

    private fun lastUsed(context: Context): Map<String, Long> = try {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val begin = end - 90L * 86_400_000L
        usm.queryAndAggregateUsageStats(begin, end).mapValues { it.value.lastTimeUsed }
    } catch (e: Exception) {
        emptyMap()
    }
}
