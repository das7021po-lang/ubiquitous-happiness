package com.speedup.app

import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File

data class BigFile(val file: File, val size: Long, val modified: Long)

object FileScanner {

    /** صلاحية "الوصول إلى كل الملفات" */
    fun hasAccess(): Boolean = Environment.isExternalStorageManager()

    /** يبحث في التخزين الداخلي عن ملفات بحجم minBytes أو أكثر، الأكبر أولًا (حتى 300 ملف). */
    suspend fun scan(minBytes: Long, onProgress: (Int) -> Unit): List<BigFile> =
        withContext(Dispatchers.IO) {
            val root = Environment.getExternalStorageDirectory()
            val found = ArrayList<BigFile>()
            val stack = java.util.ArrayDeque<File>()
            stack.push(root)
            var visited = 0
            while (stack.isNotEmpty()) {
                ensureActive()
                val dir = stack.pop()
                val children = dir.listFiles() ?: continue
                for (f in children) {
                    if (f.isDirectory) {
                        // مجلد Android يحوي بيانات التطبيقات ولا يمكن الوصول إليه أصلًا
                        if (dir == root && f.name == "Android") continue
                        stack.push(f)
                    } else {
                        visited++
                        if (visited % 500 == 0) onProgress(visited)
                        val len = f.length()
                        if (len >= minBytes) found.add(BigFile(f, len, f.lastModified()))
                    }
                }
            }
            onProgress(visited)
            found.sortedByDescending { it.size }.take(300)
        }

    /** يحذف الملفات نهائيًا ويرجع (عدد المحذوف، البايتات المحرَّرة). */
    suspend fun delete(files: List<File>): Pair<Int, Long> = withContext(Dispatchers.IO) {
        var n = 0
        var bytes = 0L
        for (f in files) {
            val len = f.length()
            if (f.delete()) {
                n++
                bytes += len
            }
        }
        n to bytes
    }
}
