package com.speedup.app.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.speedup.app.AppRow
import com.speedup.app.AppsRepo
import com.speedup.app.fmtAgo
import com.speedup.app.fmtSize
import com.speedup.app.pkgUri
import com.speedup.app.tryStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun AppsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current

    var tick by remember { mutableIntStateOf(0) }
    var usageOk by remember { mutableStateOf(AppsRepo.hasUsageAccess(context)) }
    var loading by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf<List<AppRow>>(emptyList()) }
    var sort by remember { mutableIntStateOf(0) } // 0 كاش، 1 حجم، 2 الأقدم استخدامًا
    var showSystem by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<AppRow?>(null) }

    // عند كل رجوع للشاشة (مثلًا بعد منح الصلاحية أو مسح الكاش) نعيد القراءة
    OnResume {
        usageOk = AppsRepo.hasUsageAccess(context)
        tick++
    }
    LaunchedEffect(tick) {
        if (tick > 0) {
            loading = true
            apps = withContext(Dispatchers.IO) { AppsRepo.load(context) }
            loading = false
        }
    }

    val now = remember(apps) { System.currentTimeMillis() }
    val shown = remember(apps, sort, showSystem) {
        val list = apps.filter { showSystem || !it.isSystemApp }
        when (sort) {
            0 -> list.sortedByDescending { it.cacheBytes }
            1 -> list.sortedByDescending { it.totalBytes }
            else -> list.sortedBy { if (it.lastUsed == 0L) Long.MIN_VALUE else it.lastUsed }
        }
    }
    val totalCache = shown.sumOf { maxOf(it.cacheBytes, 0L) }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenTitle("التطبيقات", "اعرف أيها يأكل المساحة والكاش ولم تستخدمه منذ مدة")

            if (!usageOk) {
                SectionCard("فعّل صلاحية الوصول لبيانات الاستخدام") {
                    Text(
                        "بدونها لا يستطيع التطبيق قراءة حجم الكاش وآخر استخدام. لا يخرج أي شيء من " +
                            "هاتفك: التطبيق بلا صلاحية إنترنت."
                    )
                    Button(onClick = {
                        tryStart(
                            context,
                            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, pkgUri(context.packageName)),
                            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                        )
                    }) { Text("فتح الإعداد") }
                }
            } else {
                Text(
                    "إجمالي الكاش في القائمة: ${fmtSize(context, totalCache)}",
                    fontWeight = FontWeight.Bold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = sort == 0, onClick = { sort = 0 }, label = { Text("الكاش") })
                FilterChip(selected = sort == 1, onClick = { sort = 1 }, label = { Text("الحجم") })
                FilterChip(
                    selected = sort == 2,
                    onClick = { sort = 2 },
                    label = { Text("الأقدم استخدامًا") }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("إظهار تطبيقات النظام")
                Switch(checked = showSystem, onCheckedChange = { showSystem = it })
            }
        }

        if (loading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
        }

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(shown, key = { it.pkg }) { app ->
                AppItem(app = app, usageOk = usageOk, now = now, onClick = { picked = app })
                HorizontalDivider()
            }
        }
    }

    picked?.let { app ->
        AlertDialog(
            onDismissRequest = { picked = null },
            title = { Text(app.label) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("الكاش: ${fmtSize(context, app.cacheBytes)}   •   الحجم: ${fmtSize(context, app.totalBytes)}")
                    TextButton(onClick = {
                        tryStart(
                            context,
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(app.pkg))
                        )
                        picked = null
                    }) { Text("فتح صفحة التطبيق (التخزين ← مسح الكاش)") }
                    if (!app.isSystemApp) {
                        TextButton(onClick = {
                            tryStart(context, Intent(Intent.ACTION_DELETE, pkgUri(app.pkg)))
                            picked = null
                        }) { Text("إلغاء التثبيت") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { picked = null }) { Text("إغلاق") } }
        )
    }
}

@Composable
private fun AppItem(app: AppRow, usageOk: Boolean, now: Long, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AppIcon(app.pkg)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                app.label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium
            )
            val sub = if (usageOk) {
                "كاش ${fmtSize(ctx, app.cacheBytes)} • الحجم ${fmtSize(ctx, app.totalBytes)} • ${fmtAgo(now, app.lastUsed)}"
            } else {
                app.pkg
            }
            Text(
                sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
