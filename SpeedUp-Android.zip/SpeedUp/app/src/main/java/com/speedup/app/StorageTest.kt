package com.speedup.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Random

data class StorageTestResult(
    val writeMBps: Double,
    val avgSyncMs: Double,
    val maxSyncMs: Double,
    val time: Long
)

/**
 * اختبار بسيط للتخزين الداخلي (للمقارنة قبل/بعد على نفس الهاتف):
 * 1) كتابة تسلسلية 256MB مع مزامنة حقيقية للقرص.
 * 2) 300 كتابة صغيرة (4KB) مع مزامنة بعد كل واحدة، وقياس المتوسط وأسوأ زمن (يكشف التقطّع).
 */
object StorageTest {
    private const val BIG_MB = 256
    private const val SMALL_OPS = 300

    suspend fun run(context: Context): StorageTestResult? = withContext(Dispatchers.IO) {
        val dir = context.cacheDir
        if (dir.usableSpace < 600L * 1024 * 1024) return@withContext null
        val big = File(dir, "st_big.tmp")
        val small = File(dir, "st_small.tmp")
        try {
            val block = ByteArray(1 shl 20)
            Random(7).nextBytes(block)

            val t0 = System.nanoTime()
            FileOutputStream(big).use { out ->
                repeat(BIG_MB) { out.write(block) }
                out.flush()
                out.fd.sync()
            }
            val seconds = (System.nanoTime() - t0) / 1e9
            val mbps = BIG_MB / seconds

            val chunk = ByteArray(4096)
            var sum = 0.0
            var worst = 0.0
            FileOutputStream(small).use { out ->
                repeat(SMALL_OPS) {
                    val s = System.nanoTime()
                    out.write(chunk)
                    out.fd.sync()
                    val ms = (System.nanoTime() - s) / 1e6
                    sum += ms
                    if (ms > worst) worst = ms
                }
            }
            StorageTestResult(mbps, sum / SMALL_OPS, worst, System.currentTimeMillis())
        } catch (e: Exception) {
            null
        } finally {
            big.delete()
            small.delete()
        }
    }
}
