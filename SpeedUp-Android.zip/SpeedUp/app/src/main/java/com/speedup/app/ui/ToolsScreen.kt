package com.speedup.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.speedup.app.AnimationTuner
import com.speedup.app.tryStart
import java.util.Locale

@Composable
fun ToolsScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var canWrite by remember { mutableStateOf(AnimationTuner.canWrite(context)) }
    var scale by remember { mutableFloatStateOf(AnimationTuner.get(context)) }
    var msg by remember { mutableStateOf<String?>(null) }

    OnResume {
        canWrite = AnimationTuner.canWrite(context)
        scale = AnimationTuner.get(context)
    }

    val cmd = "adb shell pm grant ${context.packageName} android.permission.WRITE_SECURE_SETTINGS"
    val scaleText = String.format(Locale.US, "%.1f", scale)
    val small = MaterialTheme.typography.bodySmall
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("أدوات", "إعدادات تغيّر الإحساس بالسرعة فعلًا")

        SectionCard("سرعة الأنيميشن") {
            Text("الحالية: $scaleText×. تقليلها إلى 0.5× يجعل فتح التطبيقات والانتقال بينها أسرع بصريًا دون أي ضرر.")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1f to "1×", 0.5f to "0.5×", 0.3f to "0.3×", 0f to "بدون").forEach { (v, label) ->
                    FilterChip(
                        selected = scale == v,
                        enabled = canWrite,
                        onClick = {
                            val ok = AnimationTuner.set(context, v)
                            scale = AnimationTuner.get(context)
                            msg = if (ok) "تم الضبط: $label" else "تعذّر التغيير"
                        },
                        label = { Text(label) }
                    )
                }
            }
            msg?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
            if (!canWrite) {
                Text(
                    "الأزرار معطّلة حتى تمنح التطبيق الصلاحية مرة واحدة من حاسوب: فعّل خيارات المطور " +
                        "ثم «تصحيح USB»، ونفّذ هذا الأمر:",
                    style = small,
                    color = muted
                )
                Text(cmd, style = small, fontFamily = FontFamily.Monospace)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = {
                        copy(context, cmd)
                        msg = "تم نسخ الأمر"
                    }) { Text("نسخ الأمر") }
                    OutlinedButton(onClick = {
                        tryStart(
                            context,
                            Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS),
                            Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
                        )
                    }) { Text("خيارات المطور") }
                }
                Text(
                    "بدون حاسوب: من خيارات المطور اضبط «مقياس حركة النافذة» و«الانتقال» و«مدة الأنيميشن» على 0.5×.",
                    style = small,
                    color = muted
                )
            }
        }

        SectionCard("اختصارات إعدادات تؤثر على السرعة") {
            Shortcut("رعاية الجهاز (سامسونج)", "التخزين والذاكرة والبطارية") { openDeviceCare(context) }
            Shortcut("البطارية", "حدود الاستخدام في الخلفية والتطبيقات النائمة") {
                tryStart(context, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            }
            Shortcut("الشاشة", "سلاسة الحركة: العالية أسلس لكنها أسخن") {
                tryStart(context, Intent(Settings.ACTION_DISPLAY_SETTINGS))
            }
            Shortcut("كل التطبيقات", "عطّل أو احذف ما لا تستخدمه") {
                tryStart(context, Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS))
            }
            Shortcut("التخزين", "نظرة النظام على المساحة") {
                tryStart(context, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
            }
        }

        SectionCard("لماذا لا يوجد زر «تنظيف الرام»؟") {
            Text(
                "منذ أندرويد 14 لا يُسمح لأي تطبيق بإغلاق عمليات تطبيقات أخرى، وقبلها كان النظام يعيد " +
                    "تشغيلها فتزيد الحرارة والاستهلاك. كاش التطبيقات الأخرى لا يُمسح إلا من صفحة كل " +
                    "تطبيق، وتبويب «التطبيقات» يوصلك إليها بنقرة.",
                style = small
            )
        }

        SectionCard("عادات تُسرّع فعلًا") {
            Text(
                "• أعد التشغيل كل بضعة أيام.\n• أبقِ 15–20٪ من التخزين فارغة.\n" +
                    "• احذف ما لا تستخدمه بدل إيقافه.\n• حدّث النظام والتطبيقات.\n" +
                    "• لا تشحن وتلعب معًا؛ الحرارة تخفّض الأداء."
            )
        }
    }
}

@Composable
private fun Shortcut(label: String, hint: String, onOpen: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text(
                hint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        FilledTonalButton(onClick = onOpen) { Text("فتح") }
    }
}

private fun openDeviceCare(context: Context) {
    val lool = "com.samsung.android.lool"
    tryStart(
        context,
        Intent().setClassName(lool, "com.samsung.android.sm.ui.cstyleboard.SmartManagerDashBoardActivity"),
        Intent().setClassName(lool, "com.samsung.android.sm.battery.ui.BatteryActivity"),
        Intent(Settings.ACTION_SETTINGS)
    )
}

private fun copy(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("cmd", text))
}
