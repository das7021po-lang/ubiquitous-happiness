package com.speedup.app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.Formatter

/** حجم مقروء (MB / GB). القيمة السالبة تعني "غير معروف". */
fun fmtSize(context: Context, bytes: Long): String =
    if (bytes < 0) "—" else Formatter.formatShortFileSize(context, bytes)

fun fmtUptime(ms: Long): String {
    val totalMin = ms / 60_000L
    val d = totalMin / (60 * 24)
    val h = (totalMin / 60) % 24
    val m = totalMin % 60
    return when {
        d > 0 -> "$d يوم و$h ساعة"
        h > 0 -> "$h ساعة و$m دقيقة"
        else -> "$m دقيقة"
    }
}

fun fmtAgo(now: Long, then: Long): String {
    if (then <= 0L) return "لم يُستخدم منذ مدة طويلة"
    val days = (now - then) / 86_400_000L
    return when {
        days < 1L -> "استُخدم اليوم"
        days == 1L -> "استُخدم أمس"
        days < 30L -> "آخر استخدام منذ $days يوم"
        else -> "آخر استخدام منذ ${days / 30} شهر"
    }
}

fun pkgUri(pkg: String): Uri = Uri.parse("package:$pkg")

/** يجرّب فتح أول Intent يعمل ويرجع true عند النجاح (مفيد لاختلاف شاشات الإعدادات بين الشركات). */
fun tryStart(context: Context, vararg intents: Intent): Boolean {
    for (intent in intents) {
        try {
            context.startActivity(intent)
            return true
        } catch (e: ActivityNotFoundException) {
            // جرّب الخيار التالي
        } catch (e: SecurityException) {
            // جرّب الخيار التالي
        }
    }
    return false
}
