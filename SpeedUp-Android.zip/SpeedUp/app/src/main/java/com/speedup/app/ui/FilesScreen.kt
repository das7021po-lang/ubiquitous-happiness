package com.speedup.app.ui

import android.content.Intent
import android.os.Environment
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.speedup.app.BigFile
import com.speedup.app.FileScanner
import com.speedup.app.fmtSize
import com.speedup.app.pkgUri
import com.speedup.app.tryStart
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun FilesScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val root = remember { Environment.getExternalStorageDirectory().absolutePath }
    val dateFormat = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }

    var access by remember { mutableStateOf(FileScanner.hasAccess()) }
    var minMb by remember { mutableIntStateOf(100) }
    var scanning by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var scanned by remember { mutableStateOf(false) }
    var files by remember { mutableStateOf<List<BigFile>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirm by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    OnResume { access = FileScanner.hasAccess() }

    val selectedBytes = files.filter { it.file.absolutePath in selected }.sumOf { it.size }

    Column(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenTitle("الملفات الكبيرة", "حرّر المساحة: التخزين الممتلئ من أكبر أسباب البطء")

            if (!access) {
                SectionCard("فعّل «الوصول إلى كل الملفات»") {
                    Text(
                        "لازمة للبحث في التخزين الداخلي وحذف ما تختاره. لا يُحذف شيء دون موافقتك، " +
                            "ولا يخرج أي شيء من هاتفك."
                    )
                    Button(onClick = {
                        tryStart(
                            context,
                            Intent(
                                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                pkgUri(context.packageName)
                            ),
                            Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        )
                    }) { Text("فتح الإعداد") }
                }
            } else {
                Text("أصغر حجم يُعرض:", fontWeight = FontWeight.Medium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(50, 100, 300).forEach { mb ->
                        FilterChip(
                            selected = minMb == mb,
                            onClick = { minMb = mb },
                            label = { Text("$mb MB") }
                        )
                    }
                }
                Button(
                    enabled = !scanning,
                    onClick = {
                        scanning = true
                        scanned = false
                        message = null
                        selected = emptySet()
                        files = emptyList()
                        progress = 0
                        scope.launch {
                            files = FileScanner.scan(minMb * 1024L * 1024L) { progress = it }
                            scanning = false
                            scanned = true
                        }
                    }
                ) { Text(if (scanning) "جارٍ الفحص… ($progress ملف)" else "ابدأ البحث") }

                message?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                if (scanned && files.isEmpty()) {
                    Text("لا توجد ملفات بهذا الحجم. جرّب حجمًا أصغر.")
                }
            }
        }

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(files, key = { it.file.absolutePath }) { bf ->
                val path = bf.file.absolutePath
                val checked = path in selected
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selected = if (checked) selected - path else selected + path }
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = checked,
                        onCheckedChange = { selected = if (it) selected + path else selected - path }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "${kindIcon(bf.file.name)} ${bf.file.name}",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val folder = bf.file.parent.orEmpty().removePrefix(root).ifEmpty { "/" }
                        Text(
                            "$folder • ${dateFormat.format(Date(bf.modified))}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(fmtSize(context, bf.size), fontWeight = FontWeight.Bold)
                }
                HorizontalDivider()
            }
        }

        if (selected.isNotEmpty()) {
            Button(
                onClick = { confirm = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) { Text("حذف المحدد (${selected.size} ملف • ${fmtSize(context, selectedBytes)})") }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("حذف ${selected.size} ملف؟") },
            text = {
                Text(
                    "سيُحذف ما اخترته نهائيًا (${fmtSize(context, selectedBytes)}) ولا يمكن التراجع. " +
                        "تأكد أنك لا تحتاجه."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    val targets = files.filter { it.file.absolutePath in selected }.map { it.file }
                    scope.launch {
                        val (n, bytes) = FileScanner.delete(targets)
                        files = files.filter { it.file.exists() }
                        selected = emptySet()
                        message = "تم حذف $n ملف وتحرير ${fmtSize(context, bytes)}"
                    }
                }) { Text("حذف نهائيًا") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("إلغاء") } }
        )
    }
}

private fun kindIcon(name: String): String =
    when (name.substringAfterLast('.', "").lowercase()) {
        "mp4", "mkv", "mov", "avi", "webm", "3gp" -> "🎬"
        "jpg", "jpeg", "png", "heic", "webp", "gif" -> "🖼"
        "mp3", "m4a", "wav", "flac", "aac", "ogg", "opus" -> "🎵"
        "zip", "rar", "7z", "tar", "gz" -> "🗜"
        "apk", "xapk", "apks" -> "📦"
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt" -> "📄"
        else -> "📁"
    }
