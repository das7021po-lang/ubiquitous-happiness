package com.speedup.app

import android.content.Context

/** يحفظ آخر نتيجة لاختبار التخزين فقط، لتقارن قبل/بعد. */
class Prefs(context: Context) {
    private val sp = context.applicationContext
        .getSharedPreferences("speedup", Context.MODE_PRIVATE)

    fun lastTest(): StorageTestResult? {
        if (!sp.contains("t_time")) return null
        return StorageTestResult(
            writeMBps = sp.getFloat("t_write", 0f).toDouble(),
            avgSyncMs = sp.getFloat("t_avg", 0f).toDouble(),
            maxSyncMs = sp.getFloat("t_max", 0f).toDouble(),
            time = sp.getLong("t_time", 0L)
        )
    }

    fun saveTest(r: StorageTestResult) {
        sp.edit()
            .putFloat("t_write", r.writeMBps.toFloat())
            .putFloat("t_avg", r.avgSyncMs.toFloat())
            .putFloat("t_max", r.maxSyncMs.toFloat())
            .putLong("t_time", r.time)
            .apply()
    }
}
