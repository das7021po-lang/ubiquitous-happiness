package com.speedup.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock

data class RamInfo(val totalBytes: Long, val availBytes: Long, val lowMemory: Boolean) {
    val usedBytes: Long get() = totalBytes - availBytes
    val usedPercent: Int get() = if (totalBytes > 0) (usedBytes * 100 / totalBytes).toInt() else 0
}

data class StorageInfo(val totalBytes: Long, val freeBytes: Long) {
    val usedBytes: Long get() = totalBytes - freeBytes
    val freePercent: Int get() = if (totalBytes > 0) (freeBytes * 100 / totalBytes).toInt() else 0
}

data class BatteryInfo(val tempC: Float, val levelPercent: Int, val charging: Boolean)

data class SystemSnapshot(
    val ram: RamInfo,
    val storage: StorageInfo,
    val battery: BatteryInfo,
    /** PowerManager.THERMAL_STATUS_* أو -1 إن لم تتوفر */
    val thermal: Int,
    val uptimeMs: Long,
    val animScale: Float
)

object SystemStats {

    fun snapshot(context: Context): SystemSnapshot = SystemSnapshot(
        ram = ram(context),
        storage = storage(),
        battery = battery(context),
        thermal = thermal(context),
        uptimeMs = SystemClock.elapsedRealtime(),
        animScale = AnimationTuner.get(context)
    )

    private fun ram(context: Context): RamInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return RamInfo(mi.totalMem, mi.availMem, mi.lowMemory)
    }

    private fun storage(): StorageInfo {
        val st = StatFs(Environment.getDataDirectory().path)
        return StorageInfo(st.totalBytes, st.availableBytes)
    }

    private fun battery(context: Context): BatteryInfo {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        return BatteryInfo(temp, pct, charging)
    }

    private fun thermal(context: Context): Int = try {
        (context.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
    } catch (e: Exception) {
        -1
    }
}
