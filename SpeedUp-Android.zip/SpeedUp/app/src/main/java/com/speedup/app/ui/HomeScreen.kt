package com.speedup.app.ui

import android.os.PowerManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.speedup.app.AppsRepo
import com.speedup.app.Prefs
import com.speedup.app.StorageTest
import com.speedup.app.StorageTestResult
import com.speedup.app.SystemSnapshot
import com.speedup.app.SystemStats
import com.speedup.app.fmtSize
import com.speedup.app.fmtUptime
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private class Rec(
    val level: Level,
    val title: String,
    val body: String,
    val actionLabel: String? = null,
    val onAction: (() -> Unit)? = null
)

/** onGo: ينتقل إلى تبويب آخر (0 رئيسية، 1 تطبيقات، 2 ملفات، 3 أدوات) */
@Composable
fun HomeScreen(modifier: Modifier = Modifier, onGo: (Int) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val owner = LocalLifecycleOwner.current
    val prefs = remember { Prefs(context) }

    var snap by remember { mutableStateOf<SystemSnapshot?>(null) }
    var usageOk by remember { mutableStateOf(AppsRepo.hasUsageAccess(context)) }
    var testing by remember { mutableStateOf(false) }
    var testFailed by remember { mutableStateOf(false) }
    var last by remember { mutableStateOf(prefs.lastTest()) }
    var previous by remember { mutableStateOf<StorageTestResult?>(null) }

    OnResume { usageOk = AppsRepo.hasUsageAccess(context) }

    // تحديث القياسات كل 3 ثوانٍ ما دامت الشاشة ظاهرة فقط
    LaunchedEffect(owner) {
        owner.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                snap = withContext(Dispatchers.IO) { SystemStats.snapshot(context) }
                delay(3000)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle("مسرّع", "قياسات حقيقية وإصلاحات فعلية، بلا وعود وهمية")

        val s = snap
        if (s == null) {
            CircularProgressIndicator()
        } else {
            StatusCard(s)
            RecsCard(buildRecs(s, usageOk, onGo))
        }

        StorageTestCard(
            testing = testing,
            failed = testFailed,
            last = last,
            previous = previous,
            onRun = {
                testing = true
                testFailed = false
                scope.launch {
                    val r = StorageTest.run(context)
                    testing = false
                    if (r == null) {
                        testFailed = true
                    } else {
                        previous = last
                        last = r
                        prefs.saveTest(r)
                    }
                }
            }
        )
    }
}

@Composable
private fun StatusCard(s: SystemSnapshot) {
    val ctx = LocalContext.current
    val ramLevel = when {
        s.ram.lowMemory || s.ram.usedPercent > 93 -> Level.Bad
        s.ram.usedPercent > 85 -> Level.Warn
        else -> Level.Good
    }
    val storageLevel = when {
        s.storage.freePercent < 10 -> Level.Bad
        s.storage.freePercent < 20 -> Level.Warn
        else -> Level.Good
    }
    val tempLevel = when {
        s.thermal >= PowerManager.THERMAL_STATUS_MODERATE || s.battery.tempC >= 42f -> Level.Bad
        s.battery.tempC >= 38f -> Level.Warn
        else -> Level.Good
    }
    val tempPercent = ((s.battery.tempC - 20f) / 30f * 100f).toInt()

    SectionCard("حالة الهاتف الآن") {
        MeterRow(
            "الذاكرة المستخدمة",
            "${fmtSize(ctx, s.ram.usedBytes)} من ${fmtSize(ctx, s.ram.totalBytes)}",
            s.ram.usedPercent,
            ramLevel
        )
        MeterRow(
            "التخزين المستخدم",
            "${fmtSize(ctx, s.storage.usedBytes)} من ${fmtSize(ctx, s.storage.totalBytes)}",
            100 - s.storage.freePercent,
            storageLevel
        )
        MeterRow(
            "حرارة البطارية",
            String.format(Locale.US, "%.1f°C", s.battery.tempC),
            tempPercent,
            tempLevel
        )
        InfoRow("الحالة الحرارية للنظام", thermalLabel(s.thermal))
        InfoRow("مدة التشغيل منذ آخر إعادة تشغيل", fmtUptime(s.uptimeMs))
        InfoRow("سرعة الأنيميشن", String.format(Locale.US, "%.1f×", s.animScale))
        Text(
            "ارتفاع الذاكرة المستخدمة أمر طبيعي: أندرويد يُبقي التطبيقات في الذاكرة عمدًا لتُفتح أسرع، " +
                "ولا يستطيع أي تطبيق تفريغها منذ أندرويد 14.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun thermalLabel(status: Int): String = when (status) {
    -1 -> "غير متاحة"
    0 -> "طبيعية"
    1 -> "دافئة قليلًا"
    2 -> "ساخنة (قد ينخفض الأداء)"
    3 -> "ساخنة جدًا (الأداء مخفّض)"
    else -> "حرجة"
}

private fun buildRecs(s: SystemSnapshot, usageOk: Boolean, onGo: (Int) -> Unit): List<Rec> {
    val out = ArrayList<Rec>()
    val day = 86_400_000L

    if (s.uptimeMs > 3 * day) {
        out.add(
            Rec(
                Level.Warn,
                "الهاتف يعمل منذ ${fmtUptime(s.uptimeMs)} بلا إعادة تشغيل",
                "إعادة التشغيل تُنهي العمليات العالقة وتفرّغ الذاكرة، وهي أنجح خطوة ضد التقطيع " +
                    "والتجمّد المفاجئ. أعد التشغيل الآن ثم قارن الإحساس ونتيجة اختبار التخزين."
            )
        )
    }

    if (s.ram.lowMemory) {
        out.add(
            Rec(
                Level.Bad,
                "الذاكرة منخفضة جدًا الآن",
                "النظام يضغط على التطبيقات الخلفية. أغلق الألعاب والمتصفحات الثقيلة من شاشة " +
                    "التطبيقات الأخيرة، أو أعد التشغيل."
            )
        )
    }

    val free = s.storage.freePercent
    if (free < 10) {
        out.add(
            Rec(
                Level.Bad,
                "التخزين شبه ممتلئ (المتبقي ${free}٪)",
                "حين يمتلئ التخزين تبطؤ الكتابة ويكثر التجمّد. اترك 15–20٪ على الأقل فارغة.",
                actionLabel = "ابحث عن الملفات الكبيرة",
                onAction = { onGo(2) }
            )
        )
    } else if (free < 20) {
        out.add(
            Rec(
                Level.Warn,
                "المساحة الحرة تقترب من الحد (المتبقي ${free}٪)",
                "الأفضل إبقاء 15–20٪ فارغة للحفاظ على سرعة الكتابة.",
                actionLabel = "ابحث عن الملفات الكبيرة",
                onAction = { onGo(2) }
            )
        )
    }

    if (s.thermal >= PowerManager.THERMAL_STATUS_MODERATE) {
        out.add(
            Rec(
                Level.Bad,
                "النظام يخفّض الأداء بسبب الحرارة",
                "هذا يسبّب بطئًا فوريًا. لا تشحن وتلعب معًا، أخرج الهاتف من الغطاء والشمس، " +
                    "وأغلق التطبيق الثقيل. يزول التقطيع بعد أن يبرد."
            )
        )
    } else if (s.battery.tempC >= 40f) {
        out.add(
            Rec(
                Level.Warn,
                "الهاتف دافئ (${String.format(Locale.US, "%.1f", s.battery.tempC)}°C)",
                "الحرارة العالية تُنزل سرعة المعالج. خفّف الحمل أو انتظر حتى يبرد."
            )
        )
    }

    if (s.animScale >= 1f) {
        out.add(
            Rec(
                Level.Info,
                "الأنيميشن بالسرعة الافتراضية (1×)",
                "جعلها 0.5× يعطي إحساسًا أسرع فورًا دون أي ضرر.",
                actionLabel = "افتح أداة الأنيميشن",
                onAction = { onGo(3) }
            )
        )
    }

    if (!usageOk) {
        out.add(
            Rec(
                Level.Info,
                "فعّل صلاحية بيانات الاستخدام",
                "لتعرف التطبيقات الأكبر كاشًا والتي لم تستخدمها منذ مدة.",
                actionLabel = "فتح التطبيقات",
                onAction = { onGo(1) }
            )
        )
    }

    if (out.isEmpty()) {
        out.add(
            Rec(
                Level.Good,
                "الأرقام الحالية سليمة",
                "لا توجد مشكلة ظاهرة. إن شعرت ببطء فجرّب اختبار التخزين أدناه وراجع تبويب «التطبيقات»."
            )
        )
    }
    return out
}

@Composable
private fun RecsCard(recs: List<Rec>) {
    SectionCard("ما الذي قد يُبطّئ هاتفك؟") {
        recs.forEachIndexed { i, r ->
            if (i > 0) HorizontalDivider()
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier
                        .padding(top = 7.dp)
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(r.level.color())
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(r.title, fontWeight = FontWeight.Bold)
                    Text(r.body, style = MaterialTheme.typography.bodyMedium)
                    val label = r.actionLabel
                    val action = r.onAction
                    if (label != null && action != null) {
                        TextButton(onClick = action) { Text(label) }
                    }
                }
            }
        }
    }
}

@Composable
private fun StorageTestCard(
    testing: Boolean,
    failed: Boolean,
    last: StorageTestResult?,
    previous: StorageTestResult?,
    onRun: () -> Unit
) {
    SectionCard("اختبار سرعة التخزين (قبل/بعد)") {
        Text(
            "يكتب ملفًا مؤقتًا بحجم 256MB ثم 300 كتابة صغيرة مع مزامنة، ثم يحذفها. شغّله قبل أي تغيير " +
                "وبعده. الأرقام للمقارنة على هاتفك فقط، وليست مثل AnTuTu.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Button(onClick = onRun, enabled = !testing) {
            Text(if (testing) "جارٍ الاختبار…" else "ابدأ الاختبار")
        }
        if (failed) {
            Text(
                "تعذّر الاختبار. تأكد من وجود 600MB فارغة على الأقل ثم أعد المحاولة.",
                color = MaterialTheme.colorScheme.error
            )
        }
        if (last != null) {
            Text(fmtResult(last))
            if (previous != null) {
                Text(
                    "مقارنة بالاختبار السابق: الكتابة التسلسلية ${pct(last.writeMBps, previous.writeMBps)}، " +
                        "زمن الكتابة الصغيرة ${pct(last.avgSyncMs, previous.avgSyncMs)} (الأقل أفضل).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun fmtResult(r: StorageTestResult): String = String.format(
    Locale.US,
    "الكتابة التسلسلية: %.0f MB/s\nمتوسط زمن الكتابة الصغيرة: %.2f ms\nأبطأ كتابة صغيرة: %.1f ms",
    r.writeMBps, r.avgSyncMs, r.maxSyncMs
)

private fun pct(now: Double, old: Double): String {
    if (old <= 0.0) return "—"
    return String.format(Locale.US, "%+.0f%%", (now - old) / old * 100.0)
}
